export default function Forbidden() {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        color: "deeppink",
        marginBottom: "16px",
      }}
    >
      Please login to view this page
    </div>
  );
}
